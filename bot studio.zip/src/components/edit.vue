<template>
  <div class="edit wrap">
    <div>
      宽：<input type="text" v-model="width">
    </div>
    <div>
      高：<input type="text" v-model="height">
    </div>
    <button @click="toggleBox1">组件1</button>
    <button @click="toggleBox2">组件2</button>
    <button>保存</button>
    <button @click="fullScreen">预览</button>
    <div>
      地图中心点坐标：</br>
      <input type="text" v-model="center.lng">
      <input type="text" v-model="center.lat">
      <button @click="changeMapCenter">确定</button>
    </div>
    <div class="box1-edit">
      <h3>组件1样式：</h3>
      <h4>标题样式：</h4>
      颜色：<input type="text" v-model="box1.title.color"></br>
      字体大小：<input type="text" v-model="box1.title.fontSize"></br>
      <h4>标题样式：</h4>
      颜色：<input type="text" v-model="box1.title.color"></br>
      字体大小：<input type="text" v-model="box1.title.fontSize"></br>
    </div>
  </div>
</template>

<script>
export default {
  name: 'edit',
  data () {
    return {
      height: '768',
      width: '1366',
      center:{
        lng: '117',
        lat: '33',
      },
      box1:{
        show: false,
    		height: '',
    		width: '',
    		top: '',
    		left: '',
    		title: {
    			fontSize: '',
    			color: '',
    		},
    		label: {
    			fontSize: '',
    			color: '',
    		},
    		backgroundColor: '',
    		opacity: '',
      },
      showBox1: false,
      showBox2: false,
    }
  },
  watch:{
    height(){
      this.$store.commit({
        type: 'changeInfo',
        data: {
          all: {
            height: this.height
          }
        },
      })
    },
    width(){
      this.$store.commit({
        type: 'changeInfo',
        data: {
          all: {
            width: this.width
          }
        },
      })
    }
  } ,
  methods:{
    fullScreen(){
      $('#view').addClass('full');
    },
    changeMapCenter(){
      console.log(this.center.lat);
      this.$store.commit({
        type: 'changeMap',
        data: {
          map: {
            center:{
              lat: this.center.lat,
              lng: this.center.lng
            },
          }
        },
      })
    },
    toggleBox1(){
      this.showBox1 = !this.showBox1
      this.$store.commit({
        type: 'changeBox1',
        data: {
          box1: {
            show: this.showBox1
          }
        },
      })
    },
    toggleBox2(){
      this.showBox2 = !this.showBox2
      this.$store.commit({
        type: 'changeBox2',
        data: {
          box2: {
            show: this.showBox2
          }
        },
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
  .edit{
    width: 100%;
    height: 100%;
  }
</style>
