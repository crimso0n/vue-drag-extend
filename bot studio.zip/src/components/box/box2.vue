<template>
  <div class="box2" id="box2">
    <Box>
      <div slot="content" class="box-content">
        <div class="chart1">
          <div class="title">当日事件统计</div>
          <Chart :options="option" :chartHandle="chartHandle1"></Chart>
        </div>
      </div>
    </Box>
  </div>
</template>

<script>
import Chart from '../common/chart'
import Box from '../common/box'
import VerticMid from '../common/VerticMid'
export default {
  name: 'box2',
  components:{
    Box,Chart,VerticMid
  },
  data () {
    return {
      chart1:'',
    }
  },
  computed:{
    option(){
      var option = {
          tooltip : {
            trigger: 'axis',
            axisPointer: {
              type: 'cross',
              label: {
                backgroundColor: '#6a7985'
              }
            }
          },
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
          },
          xAxis : {
            type : 'category',
            boundaryGap : false,
            axisLine: {
              show: false,
            },
            splitLine: {
              show: false,
            },
            data : ['1','2','3','4','5','6','7']
          },
          yAxis : {
            type : 'value',
            splitLine: {
              show: false,
            },
          },
          series : [
            {
              name:'事件数',
              type:'line',
              stack: '总量',
              connectNulls: false,
              smooth: true,
              itemStyle: {
                normal: {
                  color: '#43abf9'
                }
              },
              areaStyle: {
                normal: {
                  color: {
                    type: 'linear',x: 0,y: 0,x2: 0, y2: 1,
                    colorStops: [{
                      offset: 0, color: '#43abf9' // 0% 处的颜色
                    }, {
                      offset: 1, color: '#212d37' // 100% 处的颜色
                    }],
                    globalCoord: false // 缺省为 false
                  }
                }
              },
              data:[120, 132, 101, 134, 90, 230, 210]
            }
          ]
      };
      return option
    }
  },
  methods:{
    chartHandle1(chart){
      if (chart) {
        this.chart1 = chart
      }
    },
  },
  mounted(){
    var box2 = document.getElementById('box2')
    var timer = null;
    EleResize.on(box2, ()=>{
      if (timer) {
        clearTimeout(timer)
      }
      timer = setTimeout(()=>{
        console.log('resize');
        this.chart1.resize();
      },0)
    });
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
  .box2{
    position: absolute;
    top: 200px;
    width: 400px;
    height: 200px;
    background-color: rgba(1, 1, 1, .7);
    color: #fff;
    z-index: 11;
    .chart1{
      width: 100%;
      height: 100%;
      position: relative;
      .title{
        position: absolute;
        font-size: 16px;
      }
    }
  }
</style>
