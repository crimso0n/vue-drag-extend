<template>
  <div class="box1" id="box1">
    <Box>
      <div slot="content" class="box-content">
        <div class="chart1">
          <div class="title">事件统计</div>
          <Chart :options="option" :chartHandle="chartHandle1"></Chart>
          <div class="text">
            <VerticMid>
              事件总数</br>
              3283件
            </VerticMid>
          </div>
        </div>
        <div class="chart2">
          <div class="title">车辆保有量</div>
          <Chart :options="option" :chartHandle="chartHandle2"></Chart>
          <div class="text">
            <VerticMid>
              事件总数</br>
              3283件
            </VerticMid>
          </div>
        </div>
      </div>
    </Box>
  </div>
</template>

<script>
import Chart from '../common/chart'
import Box from '../common/box'
import VerticMid from '../common/VerticMid'
export default {
  name: 'box1',
  components:{
    Box,Chart,VerticMid
  },
  data () {
    return {
      chart1:'',
      chart2:'',
    }
  },
  computed:{
    option(){
      var option = {
        color: ['#fe8074','#65f6b4'],
        tooltip: {
          trigger: 'item',
          // formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        series: [
          {
            name:'事件统计',
            type:'pie',
            radius: ['50%', '70%'],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: false,
                position: 'center'
              },
            },
            labelLine: {
              normal: {
                show: false
              }
            },
            data:[
              {value:35, name:'交通事故',
              itemStyle: {
                normal: {
                  color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [{offset: 0, color: '#fe8a70'  },
                  {offset: 1, color: '#fe7877'}], false)
                }
              }},
              {value:310, name:'道路施工',
                itemStyle: {
                  normal: {
                      color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [{offset: 0, color: '#69f9b0'  },
                      {offset: 1, color: '#04a5fc'}], false)
                  }
              }}
            ]
          }
        ]
      };
      return option
    }
  },
  methods:{
    chartHandle1(chart){
      if (chart) {
        this.chart1 = chart
      }
      this.chart1.on('click',()=>{
        console.log(123);
      })
    },
    chartHandle2(chart){
      if (chart) {
        this.chart2 = chart
      }
      this.chart2.on('click',()=>{
        console.log(456);
      })
    }
  },
  mounted(){
    var box1 = document.getElementById('box1')
    var timer = null;
    EleResize.on(box1, ()=>{
      if (timer) {
        clearTimeout(timer)
      }
      timer = setTimeout(()=>{
        console.log('resize');
        this.chart1.resize();
        this.chart2.resize();
      },0)
    });
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
  .box1{
    position: absolute;
    width: 400px;
    height: 200px;
    background-color: rgba(1, 1, 1, .7);
    color: #fff;
    z-index: 11;
    .chart1,.chart2{
      float: left;
      width: 50%;
      height: 100%;
      position: relative;
      .title{
        position: absolute;
        font-size: 16px;
      }
      .text{
        position: absolute;
        width: 40%;
        height: 40%;
        top: 30%;
        left: 30%;
        font-size: 14px;
        text-align: center;
      }
    }
  }
</style>
